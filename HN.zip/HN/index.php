<?php
  date_default_timezone_set('Africa/Lagos');
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/reg.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" media="screen and (max-width:947px)" type="text/css" href="css/medium.css">
  <link rel="stylesheet" media="screen and (min-width:801px) and (max-width:946px)" type="text/css" href="css/smaller.css">
  <link rel="stylesheet" media="screen and (min-width:547px) and (max-width:800px)" type="text/css" href="css/small.css">
  <link rel="stylesheet" media='screen and (max-width:546px)' type="text/css" href="css/xtrasmall.css">

    <title>Home</title>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Awesome</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">About</a>
        </li>
      </ul>
      <ul class="nav navbar-nav">
          <li class="nav-item">
          <a class="nav-link active" href="#">Register</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Login</a>
        </li>
      </ul>
    </div>
  </nav>
    <div id="reg-cover"><br>
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
          	<div class="col-md-4 Time">The Time is : <?php echo date('H:i:s a') ?></div>
            <div class="form-cov animated flipInY">
            <span><img src="img/logor.png"></span>
            <h5 class="display-">Register to Get Started</h5>
            <div>
              <form class="form-group">
                <div class="form-group">
                  <input class="form-control" type="text" name="" placeholder="Full Name">
                </div>
                <div class="form-group">
                  <input class="form-control" type="text" name="" placeholder="Email">
                </div>
                <div class="form-group">
                  <input class="form-control" type="number" name="" placeholder="Phone">
                </div>
                 <div class="form-group">
                  <input class="form-control" type="text" name="" placeholder="Username">
                </div>
                <div class="form-group">
                  <input class="form-control" type="password" name="" placeholder="Password">
                </div>
                <div class="form-group">
                  <input class="form-control" type="password" name="" placeholder="Confirm Password">
                </div>
                <button class="btn btn-secondary btn-block">Submit</button>
                <p>Already a Member? <a href="#"> Login Now </a></p>
              </form>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer bg-dark">
      <div class="container">
        <span class="">Place sticky footer content here.</span>
      </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>